#!/bin/bash

cd /opt/development/projects/f5/ops/pki/

# Ansible playbook variables
ansible_cmd="ansible-playbook"
playbook_path="/opt/development/projects/f5/ops/pki/"
playbook_file="pki.yml"
ansible_inventory="/opt/development/projects/f5/ops/pki/inventories/production/"
vault_file="/opt/development/projects/f5/prod/.vault"
virtual_env="activenv.lnk"

# Extract FQDN from Certbot
cert_fqdn="$RENEWED_DOMAINS"

# source the virtual environment
source $virtual_env /bin/activate

# Run the Ansible playbook and pass the FQDN
sudo $ansible_cmd -i "$ansible_inventory" "${playbook_path}${playbook_file}" -vvv --vault-password-file=$vault_file -e "cert_fqdn=$cert_fqdn"
