#!/bin/bash
#

#Create current date/time stamp variable
DATETIME="`date +%d_%m_%Y`"

#Create filename variable
UCS_FILENAME="${DATETIME}_${HOSTNAME}"

#UCS Files will be saved to /var/local/ucs/
#SCF Files will be saved to /var/local/scf/
[ ! -d /var/local/ucs ] && mkdir /var/local/ucs
#[ ! -d /var/local/scf ] && mkdir /var/local/scf

#Create a UCS archive with the filename specified above
#The file extension will be .ucs . will be available in the GUI
tmsh save sys ucs "${UCS_FILENAME}"

#Also create an SCF file with the same filename
#The file extension will be .scf won't be available in the GUI
#tmsh save sys config file "${UCS_FILENAME}.scf" no-passphrase

#Change the +31 value (31 days) to whatever suits you
find /var/local/ucs/ -mtime +1 -delete -name *_${HOSTNAME}.ucs
#find /var/local/scf/ -mtime +1 -delete -name *_${HOSTNAME}.scf

#Copy backup to remote server
/usr/bin/rsync -av -e "ssh -i /home/admin/.ssh/id_rsa -o StrictHostKeyChecking=no" /var/local/ucs/* f5admin@131.224.64.220:/data/archive/f5/{{ inventory_hostname }}/
#/usr/bin/rsync -av -e "ssh -i /home/admin/.ssh/id_rsa" /var/local/scf/* f5backup@{{ backup_host }}:backup/{{ inventory_hostname }}/
#EOF
