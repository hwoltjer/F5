from f5_api import F5_API
from vips import extract_vip_info
from excel import write_to_excel
from pprint import pprint
import getpass

def main():
   
    f5_node = input("Enter the FQDN of the F5 node: ").strip()
    user = input("Enter your ADM user account: ").strip()
    password = getpass.getpass("Enter your password: ")
    output = f"vipinfo_{f5_node}.xlsx"

    f5 = F5_API(f5_node, user, password)
    
    vips = f5.get_vips()

    vipinfo = extract_vip_info(vips, f5)

    write_to_excel(vipinfo, output)
    
if __name__ == "__main__":
    main()
