import openpyxl
import json
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment

def write_to_excel(vipinfo, output_file):
    print(f"Writing vipinfo results to Excel: {output_file}")

    wb = openpyxl.Workbook()
    main_sheet = wb.active
    main_sheet.title = "VIP Summary"
    full_sheet = wb.create_sheet("FullContent")

    # Styles
    header_font = Font(size=14, bold=True)
    hyperlink_font = Font(color="0000FF", underline="single")
    data_font = Font(size=12, bold=True)
    border = Border(left=Side(style="thin", color="000000"),
                    right=Side(style="thin", color="000000"),
                    top=Side(style="thin", color="000000"),
                    bottom=Side(style="thin", color="000000"))
    yellow_fill = PatternFill(start_color="FFFFE0", end_color="FFFFE0", fill_type="solid")
    gray_fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
    blue_fill = PatternFill(start_color="ADD8E6", end_color="ADD8E6", fill_type="solid")
    green_fill = PatternFill(start_color="7CFC00", end_color="7CFC00", fill_type="solid")

    wrap_alignment = Alignment(wrap_text=True)
    nowrap_alignment = Alignment(wrap_text=False)

    # Headers
    summary_headers = ["vip", "irules", "policies"]
    full_headers = ["vip", "full irule content", "full policy content"]
    main_sheet.append(summary_headers)
    full_sheet.append(full_headers)

    # Style headers
    for col, header in enumerate(summary_headers, start=1):
        cell = main_sheet.cell(row=1, column=col)
        cell.font = header_font
        cell.border = Border(bottom=Side(style="thick", color="000000"))
        cell.fill = yellow_fill

    for col, header in enumerate(full_headers, start=1):
        cell = full_sheet.cell(row=1, column=col)
        cell.font = header_font
        cell.border = Border(bottom=Side(style="thick", color="000000"))
        cell.fill = yellow_fill

    row_num_main = 2
    row_num_full = 2

    for vip in vipinfo:
        vip_name = vip.get('name', 'N/A')
        irules = vip.get('irules', []) or ['N/A']
        policies = vip.get('policies', []) or ['N/A']
        irule_contents = vip.get('irule_contents', {})
        policy_contents = vip.get('policies_content', {})

        irules_str = "\n".join(f"- {i}" for i in irules)
        policies_str = "\n".join(f"- {p}" for p in policies)

        # Multiline formatting
        irule_content_full = "\n\n".join(
            irule_contents.get(i, "No Content").strip() for i in irules
        )
        policy_content_full = "\n\n".join(
            json.dumps(policy_contents.get(p, {}), indent=2) for p in policies
        )

        # Write to full content sheet
        full_data = [vip_name, irule_content_full, policy_content_full]
        for col, value in enumerate(full_data, start=1):
            cell = full_sheet.cell(row=row_num_full, column=col, value=value)
            cell.font = data_font
            cell.border = border
            cell.alignment = wrap_alignment

            if row_num_full % 2 == 0:
                cell.fill = gray_fill

            # Color fill logic
            if col == 2:
                cell.fill = blue_fill  # iRule content column
            elif col == 3:
                cell.fill = green_fill  # Policy content column

        # Write to main sheet (with hyperlink)
        link = f"#'FullContent'!A{row_num_full}"
        vip_cell = main_sheet.cell(row=row_num_main, column=1, value=vip_name)
        vip_cell.hyperlink = link
        vip_cell.font = hyperlink_font
        vip_cell.border = border
        vip_cell.alignment = nowrap_alignment
        if row_num_main % 2 == 0:
            vip_cell.fill = gray_fill

        # Write irules and policies columns
        irules_cell = main_sheet.cell(row=row_num_main, column=2, value=irules_str)
        irules_cell.font = data_font
        irules_cell.border = border
        irules_cell.alignment = wrap_alignment
        if row_num_main % 2 == 0:
            irules_cell.fill = gray_fill

        policies_cell = main_sheet.cell(row=row_num_main, column=3, value=policies_str)
        policies_cell.font = data_font
        policies_cell.border = border
        policies_cell.alignment = wrap_alignment
        if row_num_main % 2 == 0:
            policies_cell.fill = gray_fill

        row_num_main += 1
        row_num_full += 1

    # Auto-fit columns
    for sheet in [main_sheet, full_sheet]:
        for col in sheet.columns:
            max_length = max(len(str(cell.value)) if cell.value else 0 for cell in col)
            sheet.column_dimensions[col[0].column_letter].width = min(max_length + 2, 80)

    # Filters
    main_sheet.auto_filter.ref = f"A1:C{row_num_main - 1}"
    full_sheet.auto_filter.ref = f"A1:C{row_num_full - 1}"

    wb.save(output_file)
    print(f"Results successfully written to {output_file}")