def extract_policies(policy_contents):
    """
    Extracts policies from a dictionary where keys are policy names and values are policy details.

    Args:
        policy_contents (dict): A dictionary where each key is a policy name, and the value is another dictionary containing policy details.

    Returns:
        dict: A dictionary where each key is a policy name and its value contains status, strategy, and rules.
    """
    
    excluded_keys = {"selfLink", "kind", "fullPath", "offset", "generation, expirySecs, length, timeout, vlanid, port"}
    extracted_policies = {}

    for policy, content in policy_contents.items():
        extracted_policies[policy] = {
            "status": content.get("status", "unknown"),
            "strategy": content.get("strategy", "unknown"),
            "rules": []
        }

        # Extract rules
        for rule in content.get("rulesReference", {}).get("items", []):
            rule_entry = {
                "name": rule.get("name", "unknown"),
                "actions": [
                    {key: value for key, value in action.items() if key not in excluded_keys}
                    for action in rule.get("actionsReference", {}).get("items", [])
                ],
                "conditions": [
                    {key: value for key, value in condition.items() if key not in excluded_keys}
                    for condition in rule.get("conditionsReference", {}).get("items", [])
                ]
            }
            extracted_policies[policy]["rules"].append(rule_entry)

    return extracted_policies