import requests

class F5_API:
    def __init__(self, f5_node, user, password, timeout=120):
        self.f5_node = f5_node
        self.auth = (user, password)
        self.timeout = timeout
        self.session = self.f5_session()

        # Disable SSL certificate verification warnings
        requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
    
    def f5_get_token(self, session, auth_url):
        
        """Retrieve authentication token from F5."""
        
        payload = {
            "username": self.auth[0],
            "password": self.auth[1],
            "loginProviderName": "tmos"
        }
        
        response = session.post(auth_url, json=payload)
        
        if response.status_code == 200:
            token = response.json().get("token", {}).get("token")
            if token:
                print("[+] Auth token retrieved successfully")
                return token
        print(f"[-] Failed to retrieve auth token: {response.text}")
        return None

    def f5_session (self):

        auth_url = f"https://{self.f5_node}/mgmt/shared/authn/login"
        session = requests.session()
        session.verify = False
        session.headers.update({'Content-Type': 'application/json'})
        session.auth = (self.auth)
        session.token = self.f5_get_token(session, auth_url)
        session.auth = None
        session.headers.update({'X-F5-Auth-Token': session.token })
        return session
    
    def f5_get_request(self, endpoint):
        """Utility function to make a GET request to F5 API."""
        url = f"https://{self.f5_node}/mgmt/tm/{endpoint}"
        response = self.session.get(url)
        response.raise_for_status()  # Raise an exception for any non-2xx response
        return response.json()

    def get_device_info(self):
        """Get device info from the F5 node."""
        print(f"Collecting device info from {self.f5_node}")
        return self.f5_get_request("cm/device")

    def get_vips(self):
        """Fetch all VIPs from the F5 node."""
        print(f"Fetching VIPs from {self.f5_node}")
        return self.f5_get_request("ltm/virtual?expandSubcollections=true")["items"]

    def get_client_ssl_profiles(self):
        """Fetch client SSL profiles from the F5 node."""
        print(f"Fetching client SSL profiles from {self.f5_node}")
        return self.f5_get_request("ltm/profile/client-ssl")["items"]

    def get_irule_content(self, irule):
        """Fetch irule content for each irule associated with vip."""
        print(f"Fetching irule content of {irule} from {self.f5_node}")
        response = self.f5_get_request(f"ltm/rule/~Common~{irule}")
        return response.get("apiAnonymous", "No Content")
    
    def get_policy_content(self, policy):
        """Fetch policy content for each policy associated with vip."""
        print(f"Fetching policy content of {policy} from {self.f5_node}")
        return self.f5_get_request(f"ltm/policy/~Common~{policy}?expandSubcollections=true")
    
    def update_client_ssl_profile(self, profile_name, new_parent_profile):
        """Update the client SSL profile with a new parent profile."""
        print(f"Updating client SSL profile {profile_name} to use parent profile {new_parent_profile}")
        url = f"https://{self.f5_node}/mgmt/tm/ltm/profile/client-ssl/{profile_name}"

        # Payload to update the parent profile
        payload = {
            "defaultsFrom": f"/Common/{new_parent_profile}"
        }

        response = requests.patch(url, headers=self.headers, auth=self.auth, json=payload, verify=False, timeout=self.timeout)

        # Check if the request was successful
        if response.status_code == 200:
            print(f"Successfully updated {profile_name} to use {new_parent_profile} as the parent profile.")
        else:
            print(f"Failed to update {profile_name}. Status Code: {response.status_code}, Response: {response.text}")
        return response
