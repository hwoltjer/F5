from policies import extract_policies

def extract_vip_info(vips, f5):
    print("Extracting VIP info")
    vip_info = []
    for vip in vips:
        if 'destination' in vip and (vip['destination'].endswith(':443') or vip['destination'].endswith('.443')):
    
            irules = [irule.replace('/Common/', '') for irule in vip.get('rules', [])]   
            policy_list = vip.get('policiesReference', {}).get('items', [])
            policies = [policy.get('name', '').replace('/Common/', '') for policy in policy_list]
            
            # Fetch iRule and Policy content from F5
            irule_contents = {irule: f5.get_irule_content(irule) for irule in irules}
            policy_contents = {policy: f5.get_policy_content(policy) for policy in policies}
            policies_content = extract_policies(policy_contents)

            vip_info.append({
                'name': vip['name'],
                'irules': irules,
                'policies': policies,
                'irule_contents': irule_contents,
                'policies_content': policies_content
            })
    return vip_info
